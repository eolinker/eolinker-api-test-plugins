window.onload = () => {
  const checkboxs = document.querySelectorAll('.eo-plugin-checkbox')

  for (let i = 0; i < checkboxs.length; i++) {
    checkboxs[i].addEventListener('change', (event) => {
      const attrType = event.target.getAttribute('data-event')
      const checkboxValue = event.target.checked
      switch (attrType) {
        case 'generateData': {
          hanldeGenerateData(checkboxValue)
          break
        }
      }
    })
  }

  getInitStatus((statusObj) => {
    if (statusObj['generateData'] !== undefined) {
      document.querySelector(".eo-plugin-checkbox[data-event='generateData']").checked = statusObj['generateData']
    }
  })
}
var manifest = chrome.runtime.getManifest()
if (manifest && manifest.plugin_type === 1) {
  document.getElementById('eo-popup-home-link').setAttribute('href', 'https://www.srdcloud.cn/')
  document.getElementById('eo-popup-logo').setAttribute('src', '../images/r-d-cloud.svg')
  document.getElementById('eo-popup-logo').style.width = '40px'
  document.getElementById('eo-popup-logo').style.height = '40px'
  // 获取id为"target"的DOM节点
  document
    .getElementById('eo-popup-logo')
    .insertAdjacentHTML('afterend', '<span style="margin-left: 5px;">研发云 API 测试插件</span>')
}
function hanldeGenerateData(checked) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { from: 'popup', event: 'generateData', data: checked })
  })
}

function getInitStatus(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { from: 'popup', event: 'init' }, cb)
  })
}
