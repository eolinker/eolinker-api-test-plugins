chrome.app.window.create('CodeDoc.html', {
    id: 'default'
});
